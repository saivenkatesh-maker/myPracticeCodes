package com.stackroute.Spring_sample;

public interface Newcoach {
public void getDailyworkout();
public void getFortune();
}
