package com.stackroute.Spring_sample;

public class Employee {
 private String Str[];
 private String Empbonus[];
public String[] getStr() {
	return Str;
}
public void setStr(String[] str) {
	Str = str;
}
public String[] getEmpbonus() {
	return Empbonus;
}
public void setEmpbonus(String[] empbonus) {
	Empbonus = empbonus;
}
 
}
