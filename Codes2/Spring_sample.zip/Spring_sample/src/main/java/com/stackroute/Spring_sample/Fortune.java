package com.stackroute.Spring_sample;

public interface Fortune {
	public void getFortune();

	

}
