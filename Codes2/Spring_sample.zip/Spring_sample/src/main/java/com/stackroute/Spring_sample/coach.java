package com.stackroute.Spring_sample;

public interface coach {
 public void getDailyWorkout();
 public void getDailyFortune();
}
