package com.sai.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringBootSaiExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBootSaiExampleApplication.class, args);
	}

}
